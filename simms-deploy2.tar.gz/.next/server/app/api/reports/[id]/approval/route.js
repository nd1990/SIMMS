var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/[id]/approval/route.js")
R.c("server/chunks/[root-of-the-server]__037j0m3._.js")
R.c("server/chunks/node_modules_bcryptjs_0vo-ar-._.js")
R.c("server/chunks/_057mkmn._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_[id]_approval_route_actions_0usb25x.js")
R.m(59993)
module.exports=R.m(59993).exports
