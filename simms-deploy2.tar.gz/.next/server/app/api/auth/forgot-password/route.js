var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/forgot-password/route.js")
R.c("server/chunks/[root-of-the-server]__2030osl._.js")
R.c("server/chunks/_05ncs1u._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/[root-of-the-server]__0l8jrgt._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_forgot-password_route_actions_1eh5g41.js")
R.m(69157)
module.exports=R.m(69157).exports
