var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/route.js")
R.c("server/chunks/[root-of-the-server]__0p331mm._.js")
R.c("server/chunks/node_modules_bcryptjs_0vo-ar-._.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/_057mkmn._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_uploads_route_actions_0w1331t.js")
R.m(35868)
module.exports=R.m(35868).exports
