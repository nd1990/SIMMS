globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ziqS-M0zgWlhJL8veLXFD/_buildManifest.js",
    "static/ziqS-M0zgWlhJL8veLXFD/_ssgManifest.js",
    "static/ziqS-M0zgWlhJL8veLXFD/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/1qmvn6-_32iep.js",
    "static/chunks/2no-nkik-u2j9.js",
    "static/chunks/turbopack-35pkh8m0vxr3s.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
