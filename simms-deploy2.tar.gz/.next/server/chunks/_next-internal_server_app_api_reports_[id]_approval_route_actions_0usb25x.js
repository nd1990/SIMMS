module.exports=[71481,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reports_%5Bid%5D_approval_route_actions_0usb25x.js.map