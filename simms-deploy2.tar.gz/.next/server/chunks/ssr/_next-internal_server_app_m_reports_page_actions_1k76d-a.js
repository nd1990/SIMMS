module.exports=[15872,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_m_reports_page_actions_1k76d-a.js.map