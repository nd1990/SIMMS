module.exports=[45499,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_employees_page_actions_0ecs5wa.js.map