module.exports=[95416,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_projects_page_actions_1hqyr3k.js.map