module.exports=[49406,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_reports_%5Bid%5D_edit_page_actions_0pdjm9s.js.map