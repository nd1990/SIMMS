module.exports=[97403,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_m_profile_page_actions_1s06m-x.js.map