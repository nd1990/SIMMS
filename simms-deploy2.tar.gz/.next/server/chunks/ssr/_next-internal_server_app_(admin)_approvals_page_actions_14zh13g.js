module.exports=[84147,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_approvals_page_actions_14zh13g.js.map