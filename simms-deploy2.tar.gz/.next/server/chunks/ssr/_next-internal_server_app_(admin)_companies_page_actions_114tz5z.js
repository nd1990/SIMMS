module.exports=[73401,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_companies_page_actions_114tz5z.js.map