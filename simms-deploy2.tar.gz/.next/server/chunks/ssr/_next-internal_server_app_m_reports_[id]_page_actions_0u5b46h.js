module.exports=[70936,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_m_reports_%5Bid%5D_page_actions_0u5b46h.js.map