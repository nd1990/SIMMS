module.exports=[52274,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_m_home_page_actions_0btia39.js.map