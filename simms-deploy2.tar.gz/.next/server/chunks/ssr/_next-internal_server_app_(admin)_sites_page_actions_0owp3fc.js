module.exports=[16666,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_sites_page_actions_0owp3fc.js.map