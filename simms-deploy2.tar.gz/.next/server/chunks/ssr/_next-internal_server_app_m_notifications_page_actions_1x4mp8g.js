module.exports=[79846,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_m_notifications_page_actions_1x4mp8g.js.map