module.exports=[48314,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_m_drafts_page_actions_0drn71o.js.map