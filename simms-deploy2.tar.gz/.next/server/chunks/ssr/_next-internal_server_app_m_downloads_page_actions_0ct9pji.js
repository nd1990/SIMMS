module.exports=[29194,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_m_downloads_page_actions_0ct9pji.js.map