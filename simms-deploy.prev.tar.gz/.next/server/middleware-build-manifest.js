globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/VIQlGBkjPAMFvhn2bD7s7/_buildManifest.js",
    "static/VIQlGBkjPAMFvhn2bD7s7/_ssgManifest.js",
    "static/VIQlGBkjPAMFvhn2bD7s7/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/1qmvn6-_32iep.js",
    "static/chunks/19gs_buxeuvrb.js",
    "static/chunks/turbopack-3qr5bwwigwuei.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
