:HL["/SIMMS/_next/static/chunks/2_8k_y8f6o8mi.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"m4hUW9JHlqKiUSPx09DQt"}
