globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/m4hUW9JHlqKiUSPx09DQt/_buildManifest.js",
    "static/m4hUW9JHlqKiUSPx09DQt/_ssgManifest.js",
    "static/m4hUW9JHlqKiUSPx09DQt/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/3css3e-60vvla.js",
    "static/chunks/1okej2ijmfebs.js",
    "static/chunks/turbopack-1mh232lndm0aq.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
